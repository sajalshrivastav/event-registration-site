<?php include('include/head.php')?>
<style>
	body {
    font-family: Arial, Helvetica, sans-serif;
    margin: 0;
  }
h1{
  
  font-size:3em;
  font-style:italic;
  text-align: center;
  line-height 1px;;
  font-weight: 400;
  color:#F28B04;
  font-family: 'Nosifer', cursive;
}
p{
  font-family: 'Nosifer', cursive;
  font-size:1.2em;  
  font-style:italic;
  text-align: center;
  font-weight: 400;
  color:#f2af04;
}
  
  html {
    box-sizing: border-box;
  }
  
  *, *:before, *:after {
    box-sizing: inherit;
  }
  
  .column {
    float: left;
    width: 33.3%;
    margin-bottom: 16px;
    padding: 0 8px;
  }
  
  .card {
    box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2);
    margin: 8px;
  }
  
  .about-section {
    padding: 50px;
    text-align: center;
    background-color: #474e5d;
    color: white;
  }
  
  .container {
    padding: 0 16px;
  }
  
  .container::after, .row::after {
    content: "";
    clear: both;
    display: table;
  }
  
  .title {
    color: grey;
  }
  
  .button {
    border: none;
    outline: 0;
    display: inline-block;
    padding: 8px;
    color: white;
    background-color: #000;
    text-align: center;
    cursor: pointer;
    width: 100%;
  }
  
  .button:hover {
    background-color: #555;
  }
  
  @media screen and (max-width: 650px) {
    .column {
      width: 100%;
      display: block;
    }
  }
</style>
<body>
	<div class="about-section" style="background: url(about.jpg);background-repeat: no-repeat;background-position: center;background-size: cover;">
		<h1>Parivartan</h1>
		<p>"Ek Chakra"</p>
		<p>National Level Cultural Fest.</p>
	  </div>
	  
	  <h2 style="text-align:center">About Our Theam</h2>
	  <p style="text-align:justify">
		The Theme is" Parivartan - Ek Yatra " .
<br>
It could took audience on a journey through various phases of different" Yuga’s "as mentioned in Hindu mythology.

Yuga in Hinduism is an epoch or era within a four-age cycle. A complete Yuga starts with the Satya Yuga,via Treta Yuga and Dvapara Yuga into a Kali Yuga.

Every ‘Yuga’ can be depicted through song-dance-drama and narration of a main occurrence of that time period. 

The mythological stories of Hirankashyap - Prahlad, Ram Van Vaas, Mahabharata etc. can be depicted beautifully through different sequences and they can be combined in to groups to blend a beautiful evening full of melodious performances.
	  </p>
	  
</body>
</html>