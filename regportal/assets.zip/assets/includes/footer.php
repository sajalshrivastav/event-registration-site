<div class="concontainer-fluid footer-bg-1 mt-5 px-0 d-print-none">
  <div class="container">
    <div class="row justify-content-center text-white text-center">
      <div class="col-md-8 py-4 ">
        <h4>Shri Ram Murti Smarak College of Engineering and Technology</h4>
        <p class="mb-0">Powered by: Department of Electrical and Electronics Engineering</p>
        <p class="mb-0">Developed by</p>
        <a class="text-white" href="#">Rishabh Srivastava</a>
        <p class="mb-0">&copy; Zest2K22 Parivartan "Ek Chakra"</p>
        <!-- <a class="text-white" href="https://github.com/nikhil777jais">Nikhil Jaiswal |</a>
        <a class="text-white" href="https://github.com/Nickhil1737">Nikhil Kumar Gangwar |</a>    
        <a class="text-white" href="https://github.com/rajat-chn">Rajat Chauhan</a> -->
      </div>
    </div>
  </div>
</div>
<script src="js/jquery.js"></script>
  <script src="js/popper.js"></script>
  <script src="js/bootstrap.js"></script>
</body>
</html>